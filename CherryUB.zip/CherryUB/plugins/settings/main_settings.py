"""Please, ignore this file."""

version = "0.1 — Beta"
module_list = {}
file_list = {}