from pyrogram import Client, filters, __version__
from plugins.settings.main_settings import module_list, version
from telegraph import Telegraph
from platform import python_version

from prefix import my_prefix

prefix = my_prefix()

file_list = {}

@Client.on_message(filters.command('modules', prefixes=prefix) & filters.me)
async def modules(client, message):
    module_names = "\n".join(module_list.keys())
    await message.edit(f"**💼 CherryUserbot modules —** \n\n<code>{module_names}</code>")